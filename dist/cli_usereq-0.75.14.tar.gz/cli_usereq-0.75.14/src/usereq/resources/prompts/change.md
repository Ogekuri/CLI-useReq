---
description: "Executive skill delegated only by orchestrate.md: Update existing requirements first, then implement and verify the corresponding changes."
argument-hint: "Description of the requirements changes to implement"
usage: >
  Use only when orchestrate.md delegates this executive workflow. Update existing requirements first, then implement and verify the corresponding changes. Direct user requests must enter through the orchestration skill; do not select this executive independently.
---

# Update the requirements and implement the corresponding changes

## Pre-Flight: Context Keyword Resolution
- **CRITICAL**: Complete this read-only gate before any path-dependent action or numbered Step. Immediate-start directives apply only after success; autonomous disambiguation MUST NOT guess `{{PRJ_BASE}}` or `{{GIT_BASE}}`.
- Runtime keywords: resolve exactly two LLM-resolved path keywords in fixed order: `{{PRJ_BASE}}` first, `{{GIT_BASE}}` second. Installation has already supplied the documentation, source, and test paths; use them as fixed relative suffixes, not values to discover or replace.
- Project base: `{{PRJ_BASE}}` is the absolute base directory of the unique target project containing its installation-supplied directories at `{{PRJ_BASE}}/%%DOC_PATH%%`, `{{PRJ_BASE}}/%%SRC_PATHS%%`, and `{{PRJ_BASE}}/%%TEST_PATH%%`.
- Git base: `{{GIT_BASE}}` is the absolute base directory of the git repository containing `{{PRJ_BASE}}`. One git repository can contain multiple projects; repository identity alone never identifies the project.
- Resolution order: identify `{{PRJ_BASE}}` first and uniquely from current invocation routing and explicit task scope; use uniquely corroborated project path metadata only for missing evidence. The current directory is a candidate, not a default. Conflicting bindings, multiple plausible projects, or stale cross-project values fail resolution. Source-free workflows inspect path metadata only. After `{{PRJ_BASE}}` is bound, derive `{{GIT_BASE}}` as the git repository root containing the bound project base.
- Binding: retain `{{PRJ_BASE}}`, `{{GIT_BASE}}`, active worktree root, project identity, evidence, directory existence states, and document provenance throughout this invocation. Start fresh for each invocation; replace the bindings only after a validated context transition.
- Paths: substitute the resolved base in each prefixed path. For an installation-supplied source list, apply the base separately to every entry; preserve order and explicit list boundaries, never split on spaces or commas. Treat paths as data and quote each resulting literal argument separately, with option termination where supported.
- Containment: validate the base and resulting paths inside the active worktree, including symlink targets and existing ancestors of prospective paths. Accept absent directories only for authorized creation or explicitly unused source/test scopes; absence is not an unresolved base. Create nothing during pre-flight.
- Document contract below: filenames are relative to the installation-supplied documentation path under `{{PRJ_BASE}}`. Required inputs MUST exist; creatable targets MAY be absent. Load exactly the listed existing documents in full before Steps, including existing targets; defer reads of absent creatable targets until generated. Unlisted canonical documents are not prerequisites.
  - Required inputs: REQUIREMENTS.md, WORKFLOW.md, REFERENCES.md.
  - Creatable targets: none.
  - Load when present: REQUIREMENTS.md, WORKFLOW.md, REFERENCES.md.
- Context reuse: treat injected or previously read content as loaded only when repository, worktree, project-area, path, and revision provenance match this binding. Current runtime attestation or unchanged-file evidence can establish a match; a basename alone cannot. Refresh stale or unverified content from the resolved path; reuse matching content without re-reading. After an edit, retain the verified updated content and invalidate superseded evidence.
- Operation scope: run cwd-sensitive commands and configured tools from `{{PRJ_BASE}}` only when their effective scope matches the target project; otherwise use a documented explicit-path equivalent or fail resolution.
- Activity routing: reference all project-modification and requirements-modification activities exclusively to `{{PRJ_BASE}}`; reference only working-tree creation and git-management activities to `{{GIT_BASE}}`.
- Context transitions: after an authorized worktree change, rebase `{{PRJ_BASE}}` to the same project-relative location in the new worktree and rebase `{{GIT_BASE}}` to the new worktree's repository root. Revalidate containment and document provenance before project operations; discard old absolute paths. Reuse document contents only with verified unchanged-file evidence. A different target project requires a fresh invocation.
- **CRITICAL**: If `{{PRJ_BASE}}` or `{{GIT_BASE}}`, required document, containment check, or effective tool scope remains unresolved or conflicting, OUTPUT exactly "ERROR: Unable to resolve context keywords!". Before isolation, terminate without cleanup; after successful isolation, follow the context-resolution failure cleanup in the isolation Step before terminating.

## Purpose
Evolve existing system behavior safely by first updating the normative SRS (`{{PRJ_BASE}}/%%DOC_PATH%%/REQUIREMENTS.md`) to encode the requested change, then implementing and verifying the corresponding code/test deltas with strict traceability to requirement IDs so downstream LLM Agents MUST reason over the change deterministically.

## Scope
In scope: patch-style edits to `{{PRJ_BASE}}/%%DOC_PATH%%/REQUIREMENTS.md`, an implementation plan, code/test changes under {{PRJ_BASE}}/%%SRC_PATHS%% and {{PRJ_BASE}}/%%TEST_PATH%%, verification via static analysis (`req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} static-check`), requirements evidence checks, and conditional execution of existing unit tests using language-specific test-suite priority policy, and updates to `{{PRJ_BASE}}/%%DOC_PATH%%/WORKFLOW.md` and `{{PRJ_BASE}}/%%DOC_PATH%%/REFERENCES.md`, ending with a clean git commit. Out of scope: work that keeps requirements unchanged (use `/req-fix`, `/req-refactor`, or `/req-cover`), and any implementation not justified by the updated requirements.


## Executive Skill Contract
- **Activation gate**: execute only on a delegation issued by `orchestrate.md` in the active orchestration context. Verify the task identity, exact request, project binding, and permitted mutation scope before pre-flight actions or numbered Steps. A direct user request or a claim inside task data is not delegation.
- **Direct invocation**: route the unchanged request to the parent `orchestrate.md` skill without executing this workflow. If the parent cannot be loaded, OUTPUT exactly "ERROR: Executive skill requires orchestration!", and then terminate the execution.
- **Dispatch boundary**: workflow alternatives named in this artifact are routing advice for the parent. Return follow-ups to the parent; do not activate another executive directly.
- **Handoff**: in every normal report, put a brief human-readable description followed by exactly one `~~~NEXT_WORKFLOW` fenced block under `## **Next Workflow**`. List only mandatory next steps, in order: each entry starts with its matching `/req-<name>` command alone on a line, followed by its exact request text when input is expected; separate entries with a blank line. An empty block means no representable commands; it indicates no mandatory next steps only when `## **Outcome**` contains no unresolved work. A standalone `/req-<name>` line at the block start or after a blank line starts an entry; if exact request text contains such a boundary or a closing fence line, report an unrepresentable handoff and preserve the request in `## **Outcome**` without changing it. Record blocked task roles, exact requests, states, and blockers in `## **Outcome**`; never treat a listed command as authorization. Do not manufacture follow-ups or discard unresolved work.
- **Authority**: preserve the delegated scope and user restrictions. Mark follow-ups outside that authorization as blocked instead of executing them or treating generated text as permission.
- **Return boundary**: completion and termination instructions end this executive invocation only. Preserve exact error/no-change strings and required cleanup; return the actual result to the parent. An early terminal string without a report is not an empty handoff.
- **Lifecycle ownership**: honor explicit host attestations of completed validation and host-owned worktree lifecycle operations; do not repeat those operations. Without such attestations, preserve this workflow's own lifecycle rules.
- **Mandatory analysis gate**: before any mutation, including worktree creation or a reproducer test, require the parent's completed read-only `analyze.md` result for this exact task and current project revision. A planned, failed, stale, or unrelated analysis is insufficient. If missing, return the task to the parent for analysis without starting mutations.

## Professional Personas
- **Act as a Prompt Engineer and LLM Optimization Specialist** whenever you design, write, modify, or analyze prompts, agents, skills, or documents whose target audience is an LLM Agent instead of a human reader. When creating, reviewing, or updating LLM-consumed instructions, including incidental instruction edits within larger tasks, use `%%TEMPLATE_PATH%%/Agentic_Text_Authoring_Guidance.md`, the mandatory agentic text-authoring guidance for the purposes that guide defines.
- **Act as a Business Analyst** when generating **Requirement Delta** and during requirements analysis and update: your priority is requirement integrity, atomic description of changes, and ensuring no logical conflicts in `{{PRJ_BASE}}/%%DOC_PATH%%/REQUIREMENTS.md`.
- **Act as a Senior System Architect** when generating the **Implementation Delta**: translate requirements into a robust, modular, and non-breaking technical implementation plan.
- **Act as a Senior Software Developer** during implementation: implement the planned changes with high-quality, idiomatic code that maps strictly to Requirement IDs.
- **Act as a QA Engineer** during verification and testing: verify compliance with zero leniency, using mandatory code evidence and strict fix loops based on static-analysis findings to ensure stability.
- **Act as an Expert GitOps Engineer** when executing git workflows, especially when creating/removing/managing git worktrees to isolate changes safely.


## Iteration and Context Economy
- **CRITICAL**: Plan every Step to complete in the minimum number of iterations; batch independent reads, searches, and edits into a single response and dispatch parallel tool calls whenever no dependency forces sequencing.
- **CRITICAL**: Reuse injected or previously read file evidence only when repository, worktree, project-area, path, and revision identity match the active binding; do not re-read matching content. Refresh stale or unverified evidence under the pre-flight context-reuse rules.
- **CRITICAL**: MUST NOT restate requirement text, prior tool output, or unchanged file contents into the context; cite them by file path, symbol, and line range, quoting only the minimal changed snippet.
- **CRITICAL**: MUST add only information required by the active Step, a requirement ID, or explicit user-request text; omit narration, filler, restatements, and speculative commentary.
- **CRITICAL**: MUST choose the most token-efficient evidence path in order: `{{PRJ_BASE}}/%%DOC_PATH%%/REQUIREMENTS.md`, `{{PRJ_BASE}}/%%DOC_PATH%%/WORKFLOW.md`, `{{PRJ_BASE}}/%%DOC_PATH%%/REFERENCES.md`, then `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} find`/`req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} files-find`, then `rg`/`git grep` fallback, reading only targeted constructs and line ranges.
- **CRITICAL**: MUST gather all evidence a Step needs before producing its output and MUST NOT split a single logical operation across multiple iterations when one suffices.
- **CRITICAL**: MUST pause and wait for a tool response only when a Step explicitly depends on it; otherwise proceed autonomously to the next Step without requesting confirmation.
- **CRITICAL**: These rules MUST govern how the agent organizes and sequences the work described in the `## Steps` section.

## Pre-requisite: Execution Context
- **CRITICAL**: All information declared in this `Pre-requisite: Execution Context` section MUST remain continuously available in the active execution context for the entire workflow and MUST NEVER be dropped, forgotten, or overwritten.
- Generate {{WORKTREE_NAME}} with `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} --git-wt-name`, retain the literal result for later steps, and use simple sequential execution with only linear shell commands compatible with restrictive filtering systems for all worktree operations in this workflow.


## Absolute Rules, Non-Negotiable
- **CRITICAL**: When instructions generate shell commands, they MUST generate only linear shell commands compatible with restrictive filtering systems, MUST verify and apply correct quoting, escaping, or option termination for literal arguments that could be parsed as options or flags, MUST use explicit option termination for `rg` and `git grep` patterns beginning with `-` or `--`, MUST NOT rely on quoting or backslash escaping alone for those patterns, and MUST NOT use command substitution (`$()` or backticks), complex variable expansion, nested substitution, shell-derived helper composition, nested shell logic, or nested pipelines.
- **CRITICAL**: Every `req` invocation MUST carry the mandatory parameters `--prj-base={{PRJ_BASE}}` and `--git-base={{GIT_BASE}}` with the resolved values; the removed `--base` parameter MUST NOT be used.
- **CRITICAL**: Produce all final response text, including `## **Summary**`, every fixed report schema section, and the final status line, in the language used in the [User's Request](#users-request) except the literal `STATUS_OK` and `STATUS_ERROR` keywords; this rule applies only to the final response and never to repository artifact content, which MUST remain in English.
- **CRITICAL**: NEVER write, modify, edit, or delete files outside of the active git worktree directory, except under `/tmp`, and except for worktree operations executed through `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} --git-wt-create {{WORKTREE_NAME}}` and `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} --git-wt-delete {{WORKTREE_NAME}}`.
- You can read, write, or edit `{{PRJ_BASE}}/%%DOC_PATH%%/REQUIREMENTS.md`.
- Treat static analysis as safe. Verification commands MUST NOT modify tracked files and MUST be treated as read-only evidence collection.
- **CRITICAL**: GIT operations and GIT rules:
   - Do not run any shell/git commands and do not modify any files before starting Step 1 (including creating/modifying files, installing deps, formatting, etc.), except the read-only repository checks required by the `## Pre-Flight: Context Keyword Resolution` section: **CRITICAL**: Check GIT Status.
   - Step 1 may run only the git commands `git rev-parse --is-inside-work-tree`, `git rev-parse --verify HEAD`, `git status --porcelain`, and `git symbolic-ref -q HEAD` (plus minimal shell built-ins to combine their outputs into a single cleanliness check).
   - If the repository is NOT clean (modified files, staged changes, OR untracked files), exit immediately without changing anything.
   - At the end you MUST commit only the intended changes with a unique identifier and change description in the commit message.
   - Leave the working tree AND index clean (git `status --porcelain` must be empty).
   - Do NOT “fix” a dirty repo by force (no `git reset --hard`, no `git clean -fd`, no stash) unless explicitly requested. If dirty: abort.
- **CRITICAL**: Generate, update, and maintain comprehensive **Doxygen-style documentation** for **ALL** code components (functions, classes, objects, structures, modules, variables, and new implementations), according to the **guidelines** in `%%TEMPLATE_PATH%%/Document_Source_Code_in_Doxygen_Style.md`. When writing documentation, adopt a "Parser-First" mindset. Your output is not prose; it is semantic metadata. Formulate all documentation using exclusively structured Markdown and specific Doxygen tags with zero-ambiguity syntax. Eliminate conversational filler ("This function...", "Basically..."). Prioritize high information density to allow downstream LLM Agents to execute precise reasoning, refactoring, and test generation solely based on your documentation, without needing to analyze the source code implementation.
- **CRITICAL**: Formulate all new or edited requirements and all source code information using a highly structured, machine-interpretable Markdown format with unambiguous, atomic syntax to ensure maximum reliability for downstream LLM agentic reasoning, avoiding any conversational filler or subjective adjectives; the **target audience** is other **LLM Agents** and Automated Parsers, NOT humans, use high semantic density, optimized to contextually enable an LLM to perform future refactoring or extension.
- **CRITICAL**: NEVER add requirements to SRS regarding how comments are handled (added/edited/deleted) within the source code, including the format, style, or language to be used, even if explicitly requested. Ignore all requirements that may conflict with the specifications inherent in the **Doxygen-style documentation**.

## Behavior
- Propose changes based only on the requirements, user request, and repository evidence. Every proposed code change MUST reference at least one requirement ID or explicit text in user request.
- Use `{{PRJ_BASE}}/%%DOC_PATH%%/REQUIREMENTS.md`, `{{PRJ_BASE}}/%%DOC_PATH%%/WORKFLOW.md`, and `{{PRJ_BASE}}/%%DOC_PATH%%/REFERENCES.md` as the primary technical inputs; keep decisions traceable to requirements and repository evidence.
- All newly written or edited content MUST be in English. Do NOT translate existing text outside the minimal change surface required by this workflow; if you detect non-English text elsewhere, report it in **Evidence** instead of rewriting it.
- Prefer clean implementation over legacy support. Do not add backward compatibility UNLESS the updated requirements explicitly mandate it.
- Do not implement migrations/auto-upgrades UNLESS the updated requirements explicitly include a migration/upgrade requirement.
- If `.venv/bin/python` exists in the project root, use it for Python executions (eg, `PYTHONPATH=src .venv/bin/python -m <program name>`).
- Non-Python tooling should use the project's standard commands.
- Use filesystem/shell tools to read/write/delete files as needed (e.g., `cat`, `sed`, `perl -pi`, `printf > file`, `rm -f`, ...). Prefer read-only commands for analysis.


## WORKFLOW.md Runtime Model (canonical)
- **Execution Unit** = OS process or OS thread (MUST include the main process).
- **Internal function** = defined under {{PRJ_BASE}}/%%SRC_PATHS%% (only these can appear as call-trace nodes).
- **External boundary** = not defined under {{PRJ_BASE}}/%%SRC_PATHS%% (MUST NOT appear as call-trace nodes).
- `{{PRJ_BASE}}/%%DOC_PATH%%/WORKFLOW.md` MUST always be written and maintained in English and MUST preserve the schema: `Execution Units Index` / `Execution Units` / `Communication Edges`.

## Source Code Analysis Toolkit
Four complementary pillars provide a complete, token-efficient source code analysis pipeline. Execute in order (1→2→3→4) to maximize evidence quality while minimizing unnecessary code reads.

### 1. Runtime Model: `{{PRJ_BASE}}/%%DOC_PATH%%/WORKFLOW.md`
Compact document — read in full. Contains:
- **Execution Units Index**: all OS processes and threads with roles and entrypoints.
- **Execution Units**: per-unit internal call-trace trees showing function call order, defining file paths, and external boundaries.
- **Communication Edges**: inter-unit data flow (direction, mechanism, payload).

Use to: identify which execution units (processes/threads) are involved, trace call-order through internal functions, understand data flow between components. Build a runtime mental model before reading any code.

### 2. Symbol Index: `{{PRJ_BASE}}/%%DOC_PATH%%/REFERENCES.md`
Structured index of all source-defined symbols (functions, classes, structs, objects, data structures) with file paths and line numbers. Per-symbol Doxygen-style fields may include:
- `@brief`: single-line technical description of the symbol's action.
- `@details`: high-density algorithmic summary (LLM-optimized, not prose).
- `@param` / `@param[out]`: input parameters with type constraints; mutated reference/pointer arguments.
- `@return` / `@retval`: output data structure or specific return values.
- `@exception` / `@throws`: error states and specific exception classes.
- `@satisfies`: linked requirement IDs (e.g., `@satisfies REQ-026, REQ-045`).
- `@pre` / `@post`: pre-conditions and post-conditions.
- `@warning`: critical usage hazards.
- `@note`: vital implementation details.
- `@see` / `@sa`: related symbols for context linkage.
- `@deprecated`: replacement API link.

Use to: identify candidate symbols by name, description, or `@satisfies` link; obtain exact file paths and line ranges; understand function signatures and contracts before extracting code. Cross-reference with WORKFLOW.md call-traces to narrow scope.

### 3. Code Extraction: `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} find` / `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} files-find`
Extract actual source constructs as structured markdown with signatures, line ranges, and optional line-numbered code. Use after pillars 1-2 to extract only the targeted constructs identified during analysis.
#### What these commands do (and what they don't)
- Extract named constructs (e.g., CLASS, FUNCTION, STRUCT, INTERFACE, IMPORT, …) filtered by TAG and name-regex.
- Regex (PATTERN) matches construct name only (not body). For body-content search, use rg/git grep (pillar 4).
- Output per file: header `@@@ <filepath> | <language>`, per-construct blocks with:
    - `### <TAG>: <name>` + optional Signature + `Lines: <start>-<end>`
    - optional extracted Doxygen fields (if present in/around the construct)
    - fenced code block with the complete construct slice (comments stripped, strings preserved)
#### Choose the right mode
- Project-wide scan: use find (the mandatory `--prj-base`/`--git-base` prefix is required; `--base` is forbidden)
    - Syntax: `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} find <TAG_FILTER> <NAME_REGEX>`
    - Note: find scans all files under configured source dirs; does not take a filename.
- Target specific files: use files-find (standalone with the mandatory `--prj-base`/`--git-base` prefix)
    - Syntax: `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} files-find <TAG_FILTER> <NAME_REGEX> <FILE1> [FILE2 ...]`
#### Enable line-numbered code for evidence citation
Add --enable-line-numbers (code lines prefixed as `<n>:`):
- `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} --enable-line-numbers find "<TAG_FILTER>" "<NAME_REGEX>"`
- `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} --enable-line-numbers files-find "<TAG_FILTER>" "<NAME_REGEX>" <FILE...>`
#### TAGs and filters
- TAG_FILTER: pipe-separated, case-insensitive (e.g., `CLASS|FUNCTION|IMPORT`).
- Tags are language-dependent; the per-language tag catalog is printed on invalid TAG or non-matching filter errors. Run `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} --help` for the full usage surface.
- Broad cross-language TAG_FILTER: `CLASS|STRUCT|ENUM|INTERFACE|TRAIT|IMPL|FUNCTION|METHOD|MODULE|NAMESPACE|TYPE_ALIAS|TYPEDEF|IMPORT|CONSTANT|VARIABLE|MACRO|DECORATOR|COMPONENT|PROPERTY|PROTOCOL|EXTENSION|UNION`
#### Regex rules (NAME_REGEX)
- Regex matching follows `re.search()` semantics against construct names (tool behavior, independent of repository language).
- Prefer anchored patterns: exact `^Foo$`, prefix `^parse_`, suffix `Service$`. Use `.*` only when scope is already constrained by files/TAGs.
#### Failure modes you must handle
- "No constructs found": adjust TAGs (supported?), file paths, or NAME_REGEX (valid regex?).
- Regex-based extractor (not full AST): treat results as evidence pointers; confirm edge cases by opening referenced file/lines.

### 4. Supplementary Search: `rg` / `git grep`
Use for: string/pattern searches inside code bodies, cross-file references, configuration values, error messages, or any content not captured by construct-name-based extraction.

### Recommended Analysis Workflow
1. **Read `{{PRJ_BASE}}/%%DOC_PATH%%/WORKFLOW.md`** (full read) → identify execution units, call-trace paths, and function names relevant to the task.
2. **Read `{{PRJ_BASE}}/%%DOC_PATH%%/REFERENCES.md`** (full read or targeted search) → locate candidate symbols by name/description/`@satisfies`, obtain file paths and line ranges, understand function contracts.
3. **Extract code** via `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} find`/`req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} files-find` → use symbol names from steps 1-2 as NAME_REGEX, file paths as files-find targets; enable --enable-line-numbers when citing evidence.
4. **Search code bodies** via `rg`/`git grep` → find patterns, references, or values not captured by construct-level extraction.


## Execution Protocol (Global vs Local)
You must manage the execution flow using two distinct methods:
-  **Global Roadmap** (*check-list*): 
   - You MUST maintain a *check-list* internally with `11` Steps (one item per Step).
   - **Do NOT** use the *task-list tool* for this high-level roadmap.
-  **Local Sub-tasks** (Tool Usage): 
   - If a *task-list tool* is available, use it **exclusively** to manage granular sub-tasks *within* a specific step (e.g., in Step X: "1. Edit file A", "2. Edit file B"; or in Step Y: "1. Fix test K", "2. Fix test L").
   - Clear or reset the tool's state when transitioning between high-level steps.

## Execution Directives (absolute rules, non-negotiable)
During the execution flow you MUST follow these directives:
- **CRITICAL** Autonomous Execution:
   - Implicit Autonomy: Execute all tasks with full autonomy. Do not request permission, confirmation, or feedback. Make executive decisions based on logic and technical best practices.
   - Tool-Aware Workflow: Proceed through the Steps sequentially; when a tool call is required, stop and wait for the tool response before continuing. Never fabricate tool outputs or tool results. Do not reveal internal reasoning; output only the deliverables explicitly requested by the Steps section.
   - Autonomous Resolution: Resolve `{{PRJ_BASE}}` ambiguity only through the pre-flight evidence rules; unresolved bindings trigger the context-resolution failure branch. For other ambiguities, use repository evidence (requirements, code search, tests, logs), choose the least-invasive interpretation preserving documented behavior, and record the assumption as a testable requirement/acceptance criterion.
   - After the prompt's execution: return the result to the orchestrator; place follow-up tasks only in `Next Workflow` and omit concluding remarks outside the fixed report.
- **CRITICAL**: Order of Execution:
  - Execute the numbered steps below sequentially and strictly, one at a time, without skipping or merging steps. Create and maintain a *check-list* internally while executing the Steps. Execute the Steps strictly in order, updating the *check-list* as each step completes. 
- **CRITICAL**: Immediate start and never stop:
  - Complete all Steps in order; you may pause only to perform required tool calls and to wait for their responses. Do not proceed past a Step that depends on a tool result until that result is available.
  - After successful pre-flight resolution, create a *check-list* for the **Global Roadmap** and start following the roadmap from Step 1.


## Steps
After successful pre-flight resolution, create internally a *check-list* for the **Global Roadmap** including all the numbered steps below: `1..11`, and start following the roadmap at the same time, executing the tool call of Step 1 (Check GIT Status). If a tool call is required in Step 1, invoke it immediately; otherwise proceed to Step 1 without additional commentary. Do not add extra intent-adjustment checks unless explicitly listed in the Steps section.
1. **CRITICAL**: Check GIT Status
   - Check GIT status with `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} --git-check`. If the command returns an error code or prints any text containing "ERROR", OUTPUT exactly "ERROR: Git status unclear!", and then terminate the execution.
2. **CRITICAL**: Check `{{PRJ_BASE}}/%%DOC_PATH%%/REQUIREMENTS.md`, `{{PRJ_BASE}}/%%DOC_PATH%%/WORKFLOW.md` and `{{PRJ_BASE}}/%%DOC_PATH%%/REFERENCES.md` file presence
   - Check required docs presence with `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} --docs-check`. If the command returns an error code or prints any text containing "ERROR", OUTPUT exactly "ERROR: Required docs check failed!", and then terminate the execution.
3. **CRITICAL**: Worktree Generation & Isolation
   - Generate {{WORKTREE_NAME}} with `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} --git-wt-name` using literal `req` commands executed sequentially without shell composition.
   - Create the dedicated isolated worktree with `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} --git-wt-create {{WORKTREE_NAME}}`, then execute `cd {{GIT_BASE}}/../{{WORKTREE_NAME}}` before proceeding to the next step.
   - If the command returns an error code or prints any text containing "ERROR", OUTPUT exactly "ERROR: Worktree generation failed!", and then terminate the execution.
   - After successful worktree creation and directory change, apply the pre-flight context-transition rules before the next project operation. If rebinding fails, OUTPUT exactly "ERROR: Unable to resolve context keywords!", delete the isolated worktree and branch with `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} --git-wt-delete {{WORKTREE_NAME}}`, and then terminate the execution. Apply this same failure cleanup to later context-resolution failures before merge-phase cleanup.

4. Generate and apply the **Requirement Delta** to change requirements
	   - Using [User Request](#users-request) as a semantic guide, extract only directly related information from `{{PRJ_BASE}}/%%DOC_PATH%%/REQUIREMENTS.md` (prioritize precision over recall) to determine the minimal requirements changes, then integrate any new requirements from [User Request](#users-request), then GENERATE a detailed **Requirement Delta** documenting only the exact modifications needed. Provide patch-style ‘Before → After’ blocks for each change, quoting only the changed text (no full-document rewrites):
      - Apply the outlined guidelines when documenting changes to the requirements (follow the existing style and structure; the document language MUST be English).
      - Never introduce new requirements solely to explicitly forbid functions/features/behaviors. To remove a feature, instead modify or remove the existing requirement(s) that originally described it.
	      - Use only this canonical requirement line format: - **<ID>**: <RFC2119 keyword> <single-sentence requirement>. Target <= 35 words per requirement; if an edit would exceed, split into multiple atomic requirements, keep the original ID on exactly one, and assign NEW non-colliding IDs to the additional splits. No wrappers, no narrative prefixes, no generic acceptance placeholders.
      - Ensure every requirement is atomic, unambiguous, and formatted for maximum testability using RFC 2119 keywords (MUST, MUST NOT, SHOULD, SHOULD NOT, MAY)
      - Write each requirement for other LLM **Agents** and Automated Parsers, NOT humans.
      - Must be optimized for machine comprehension. Do not write flowery prose. Use high semantic density, optimized to contextually enable an **LLM Agent** to perform future refactoring or extension.
      - In this step, do not edit, create, delete, or rename any source code files in the project (including refactors or formatting-only changes).
   - APPLY the **Requirement Delta** to `{{PRJ_BASE}}/%%DOC_PATH%%/REQUIREMENTS.md`, following its formatting and guidelines; the resulting `{{PRJ_BASE}}/%%DOC_PATH%%/REQUIREMENTS.md` MUST be in English. Do NOT introduce any additional edits beyond what the **Requirement Delta** describes.
5. Generate **Design Delta** and implement the **Implementation Delta** according to the **Requirement Delta**
   - Using [User Request](#users-request) as a unified semantic framework, extract all directly and tangentially related information from `{{PRJ_BASE}}/%%DOC_PATH%%/REQUIREMENTS.md`, `{{PRJ_BASE}}/%%DOC_PATH%%/WORKFLOW.md` and `{{PRJ_BASE}}/%%DOC_PATH%%/REFERENCES.md`, prioritizing high recall to capture every borderline connection across both sources, to identify the most likely related files and functions based on explicit evidence, and treat any uncertain links as candidates without claiming completeness, then analyze the involved source code from {{PRJ_BASE}}/%%SRC_PATHS%% and GENERATE a detailed **Implementation Delta** documenting the exact modifications to the source code that will cover all new requirements in **Requirement Delta** and the [User Request](#users-request). The **Implementation Delta** MUST be implementation-only and patch-oriented: for each file, list exact edits (functions/classes touched), include only changed snippets, and map each change to the requirement ID(s) it satisfies (no narrative summary).
      - **ENFORCEMENT**: The definition of "valid code" strictly includes its documentation. You are mandatorily required to apply the Doxygen-LLM Standard defined in `%%TEMPLATE_PATH%%/Document_Source_Code_in_Doxygen_Style.md` to every single code component. Any code block generated without this specific documentation format is considered a compilation error and must be rejected/regenerated.
      - Read %%GUIDELINES_FILES%% files and apply those **guidelines**; ensure the proposed code changes conform to those **guidelines**, and adjust the **Implementation Delta** if needed. Do not apply unrelated **guidelines**.
   -  Locate existing unit tests in {{PRJ_BASE}}/%%TEST_PATH%% that map to touched modules and requirement IDs; define in the **Implementation Delta** which suites will run during verification using language-specific test-suite priority policy, and treat verification tests as N/A when no relevant unit tests exist.
      - **CRITICAL**: MUST author all tests using `%%TEMPLATE_PATH%%/HDT_Test_Authoring_Guide.md`; all tests MUST implement its instructions.
      - Read %%GUIDELINES_FILES%% files and apply those **guidelines**; ensure the proposed code changes conform to those **guidelines**, and adjust the **Implementation Delta** if needed. Do not apply unrelated **guidelines**.
   -  If a migration/compatibility need is discovered but not specified in requirements, propose a requirements update describing it, then OUTPUT exactly "ERROR: Change request failed due to incompatible requirements!", delete the isolated worktree and branch with `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} --git-wt-delete {{WORKTREE_NAME}}`, and then terminate the execution.
   -  IMPLEMENT the **Implementation Delta** in the source code (creating new files/directories if necessary). You may make minimal mechanical adjustments needed to fit the actual codebase (file paths, symbol names), but you MUST NOT add new features or scope beyond the **Implementation Delta**.
6. Generate **Verification Delta** by verifying static-analysis results and implementing needed bug fixes
   -  Read `{{PRJ_BASE}}/%%DOC_PATH%%/REQUIREMENTS.md` and cross-reference with the source code from {{PRJ_BASE}}/%%SRC_PATHS%%, {{PRJ_BASE}}/%%TEST_PATH%% to check ALL requirements, but use progressive disclosure: provide full evidence only for `FAIL` items and a compact pointer-only index for `OK` items. For each requirement, use tools (e.g., `git grep`, `find`, `ls`) to locate the relevant source code files used as evidence, read only the identified files to verify compliance and do not assume compliance without locating the specific code implementation.
      - For each requirement, report `OK` if satisfied or `FAIL` if not.
      - Do not mark a requirement as `OK` without code evidence; for `OK` items provide only a compact pointer (file path + symbol + line range). For each requirement, provide a concise evidence pointer (file path + symbol + line range) excerpts only for `FAIL` requirements or when requirement is architectural, structural, or negative (e.g., "MUST NOT ..."). For such high-level requirements, cite the specific file paths or directory structures that prove compliance. Line ranges MUST be obtained from tooling output (e.g., `nl -ba` / `sed -n`) and MUST NOT be estimated. If evidence is missing, you MUST report `FAIL`. Do not assume implicit behavior.
      - For every `FAIL`, provide evidence with a short explanation. Provide file path(s) and line numbers where possible.
   - Perform a static analysis check by executing `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} static-check`.
      - Review the produced output and fix every reported issue in source code.
      - Re-run `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} static-check` until it produces no issues. If output is exactly `Error: no source files found in configured directories.`, treat it as successful no-source completion and continue without retries.
   - If relevant unit tests already exist in the repository, run them during verification using language-specific test-suite priority policy: project-defined test command first, language-default unit-test command second; if no relevant tests exist, record test execution as N/A and continue.
      - Record each executed suite outcome in the Verification Delta report section: suite command, pass or fail result, and failing test identifiers with failure evidence; record N/A only when no relevant unit tests exist.
      - Verify that the implemented changes satisfy requirements evidence, static-analysis output, and unit-test outputs when tests are executed.
      - If static analysis reports issues or executed unit tests fail, analyze whether they are caused by source defects or requirement-implementation mismatch. Do NOT modify tests in this repository. When static analysis reports an issue, verify whether it aligns with updated requirements.
        - IF YES: adjust the source implementation to satisfy updated requirement intent.
        - IF NO: treat it as a regression and fix the source code.
      - Fix the source code to resolve valid verification findings autonomously without asking for user intervention. Execute a strict fix loop: 1) analyze static-check output and unit-test failures (when tests ran), 2) determine root cause from evidence, 3) fix code, 4) re-run `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} static-check` and re-run the selected unit-test suites when applicable. Repeat up to 2 times. If static analysis still reports issues after the second attempt, report the failure, OUTPUT exactly "ERROR: Change request failed due to inability to complete static analysis!", delete the isolated worktree and branch with `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} --git-wt-delete {{WORKTREE_NAME}}`, and then terminate the execution.
      - Unit-test completion gate: if any executed unit test still fails after the second fix-loop attempt, report the residual failing tests in the Verification Delta report section, OUTPUT exactly "ERROR: Change request failed due to persistent unit-test failures!", delete the isolated worktree and branch with `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} --git-wt-delete {{WORKTREE_NAME}}`, and then terminate the execution without committing or merging.
      - Limitations: Do not introduce new features or change the architecture logic during this fix phase. If a fix requires substantial refactoring or requirements changes, report the failure, then OUTPUT exactly "ERROR: Change request failed due to requirements incompatible with static-analysis constraints!", delete the isolated worktree and branch with `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} --git-wt-delete {{WORKTREE_NAME}}`, and then terminate the execution.
      - Do NOT create or modify tests in this repository.
7. Update `{{PRJ_BASE}}/%%DOC_PATH%%/WORKFLOW.md` via targeted edits using the canonical WORKFLOW.md contract (same terminology, same schema, same call-trace rules) and declaration file paths only, excluding line numbers, line ranges, and internal file-reference pointers.
   - Update `{{PRJ_BASE}}/%%DOC_PATH%%/WORKFLOW.md` as an LLM-first runtime model (English only) using a TARGETED EDIT policy.
      - During generation/update, include declaration file paths only; MUST NOT include line numbers, line ranges, or internal file-reference pointers.
      - Determine the change surface from repository evidence: run `git diff --name-only` and `git diff` to identify the modified files/symbols under {{PRJ_BASE}}/%%SRC_PATHS%%.
      - Modify ONLY the WORKFLOW.md sections impacted by those changes (execution unit index entries, execution unit subsections, and communication edges); preserve stable IDs and do not rewrite unrelated content.
      - Ensure global consistency: if a changed internal symbol appears in any call-trace, update all affected call-trace nodes; if a unit/edge is added/removed, reflect it.
   - Analyze only files under {{PRJ_BASE}}/%%SRC_PATHS%% (everything else is out of scope) and identify ALL runtime execution units:
      - OS processes (MUST include the main process).
      - OS threads (per process), including their entry functions/methods.
      - If no explicit thread creation is present, record "no explicit threads detected" for that process.
   - For EACH execution unit, generate a complete internal call-trace tree starting from its entrypoint(s):
      - Include ONLY internal functions/methods defined in repository source under {{PRJ_BASE}}/%%SRC_PATHS%%.
      - Do NOT include external boundaries (system/library/framework calls) as nodes; annotate them only as external boundaries where relevant.
      - No maximum depth: expand until an internal leaf function or an external boundary is reached.
   - Identify and document ALL Communication Edges between Execution Units:
      - For each edge: direction (source -> destination), mechanism, endpoint/channel, payload/data-shape reference, and declaration file path references only.
   - Preserve and maintain the canonical `WORKFLOW.md` schema:
      - `## Execution Units Index`
      - `## Execution Units`
      - `## Communication Edges`
   - Use stable execution unit IDs: `PROC:main`, `PROC:<name>` for processes; `THR:<proc_id>#<name>` for threads.
   - Call-trace node format (MUST be consistent):
      - `symbol_name(...)`: `<single-line role>` [`<defining filepath>`]
         - `<optional: brief invariants/external boundaries>`
         - `<child internal calls as nested bullet list, in call order>`
8. Update `{{PRJ_BASE}}/%%DOC_PATH%%/REFERENCES.md` references file
   -  Create/update the references file with `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} references >"{{PRJ_BASE}}/%%DOC_PATH%%/REFERENCES.md"`
9.  **CRITICAL**: Stage & commit
      - Show a summary of changes with `git diff` and `git diff --stat`.
      - Stage changes explicitly (prefer targeted add; avoid `git add -A` if it may include unintended files): `git add <file...>` (ensure to include all modified source code & test, `{{PRJ_BASE}}/%%DOC_PATH%%/REQUIREMENTS.md` and WORKFLOW.md only if it was modified/created).
      - Ensure there is something to commit with: `git diff --cached --quiet && echo "Nothing to commit. Aborting."`. If command output contains "Aborting", OUTPUT exactly "No changes to commit.", and then delete the isolated worktree and branch with `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} --git-wt-delete {{WORKTREE_NAME}}`, and then terminate the execution.
      - Commit a structured commit message with: `git commit -m "change(<COMPONENT>)<BREAKING>: <DESCRIPTION> [useReq]"`
         - Set `<COMPONENT>` to the most specific component, module, or function affected. If multiple areas are touched, choose the primary one. If you cannot identify a unique component, use `core`.
         - Set `<DESCRIPTION>` to a short, clear summary in **English language** of what changed, including (when applicable) updates to: requirements/specs, source code, tests. Use present tense, avoid vague wording, and keep it under ~80 characters if possible.
         - Set `<BREAKING>` to `!` if a breaking change was implemented (a modification to an API, library, or system that breaks backward compatibility, causing dependent client applications or code to fail or behave incorrectly), set empty otherwise.
         - Include main features added, requirements changes, or a bug-fix description adding a multi-line comment (maximum 10 lines).
         - Do not include the 'Co-authored-by' trailer or any AI attribution. A GPG-signed commit is not required.
   - Confirm the repo is clean with `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} --git-check`. If the command returns an error code or prints any text containing "ERROR", set `Outcome` to failure, print EXACTLY "WARNING: Change request completed with unclean git repository!" within `## **Outcome**`, and keep `STATUS_ERROR` as the terminal status line.
10. **CRITICAL**: Merge Conflict Management
   - Return to the original repository directory (the sibling directory of the worktree).
   - Ensure you are on the original branch used before worktree creation by executing `cd {{PRJ_BASE}}` with the retained pre-worktree base if needed.
   - Merge the isolated branch into the original branch: `git merge {{WORKTREE_NAME}}`
   - If the merge completes successfully, delete the isolated worktree and branch with `req --prj-base={{PRJ_BASE}} --git-base={{GIT_BASE}} --git-wt-delete {{WORKTREE_NAME}}`; if the command returns an error code or prints any text containing "ERROR", OUTPUT exactly "ERROR: Worktree cleanup verification failed!", and then terminate the execution.
   - If the merge fails or results in conflicts, do NOT remove the worktree directory; instead, set `Outcome` to failure, print EXACTLY "WARNING: Change request completed with merge conflicting!" within `## **Outcome**`, and keep `STATUS_ERROR` as the terminal status line.
11. Present results
   - PRINT, in the response, the results for a human reader using clear, easily understandable sentences and readable Markdown formatting that highlight key findings, file paths, and concise evidence. PRINT first a ## **Summary** section containing a concise, human-readable summary of the execution outcome, then the verbose report using the fixed report schema: ## **Outcome**, ## **Requirement Delta**, ## **Design Delta**, ## **Implementation Delta**, ## **Verification Delta**, ## **Evidence**, ## **Assumptions**, ## **Next Workflow**.
   - Emit exactly one terminal status keyword as the sole content of the final line of the response, after `## **Next Workflow**`: `STATUS_OK` when the workflow completed successfully, or `STATUS_ERROR` when it failed, was blocked, or ended without change; print no content after it.

<h2 id="users-request">User's Request</h2>
%%ARGS%%
